#include <iostream>
#include <sstream>

#define ll long long 
using namespace std;
template <class _O_> string To_string(_O_ _XXX_)
{
    ostringstream C_C;
    C_C << _XXX_;
    return C_C.str();
}

ll findNthDigit(ll n) {
	ll len = 1;
      ll cnt = 9;
      ll start = 1;
      while(n > len * cnt) {
          n -= len * cnt;
          cnt *= 10;
          start *= 10;
          len++;
      }
      start += (n - 1) / len;
      string s = To_string(start);
      return s[(n - 1) % len] - '0';
}
 
int main() {
    freopen("digit.inp","r",stdin);
    freopen("digit.out","w",stdout);
    ll t;
    cin >> t;
    while (t--) {
        ll n;
        cin >> n;
        cout << findNthDigit(n) << '\n';
    }
}