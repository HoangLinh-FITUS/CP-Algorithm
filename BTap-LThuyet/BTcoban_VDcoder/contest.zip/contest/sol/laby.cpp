#include <bits/stdc++.h>
#define ll int
#define fu(i,a,b) for(ll i = a; i <= b; i++)
#define fi first
#define se second
#define ii pair<ll,ll>
 
using namespace std;
const ll Gmax = 3*1e3 + 1;
 
ll n,m,XC,YC;
char a[Gmax][Gmax];
ll xd,xc,yd,yc;
ii trace[Gmax][Gmax];
ll h[] = {0,0,-1,1};
ll c[] = {1,-1,0,0};
 
 
void bfs()
{
    queue <ii> q;
    q.push({xd,yd});
    while (!q.empty())
    {
        ll ux = q.front().fi;
        ll uy = q.front().se;
        q.pop();
        for(ll i = 0;i < 4; i++)
        {
            ll x = ux + h[i];
            ll y = uy + c[i];
            if (a[x][y] == '.' && x > 0 && y > 0 && y <= m && x <= n)
            {
                a[x][y] = '#';
                trace[x][y] = {ux,uy};
                q.push({x,y});
            }
        }
    }
}
 
int main() {
    freopen("laby.inp","r",stdin);
    freopen("laby.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    fu(i,1,n) fu(j,1,m) {
        cin >> a[i][j];
        if (a[i][j] == 'A') xd = i,yd = j,a[i][j] = '.';
        if (a[i][j] == 'B') xc = i,yc = j,a[i][j] = '.';
    }
    bfs();
    if (a[xc][yc] == '.')
    {
        cout << "NO";
        return 0;
    }
    ll u = xc,v = yc,x,y;
    string xau = "";
    while (ii(u,v) != ii(xd,yd))
    {
        x = u;y = v;
        a[x][y] = 'x';
        ii tv = trace[u][v];
        u = tv.fi;v = tv.se;
        if (x + 1 == u && y == v) xau += 'U';
        if (x - 1 == u && y == v) xau += 'D';
        if (x == u && y + 1 == v) xau += 'L';
        if (x == u && y - 1 == v) xau += 'R';
    }
    reverse(xau.begin(),xau.end());
    cout << "YES" << '\n' << xau.size();// << '\n' << xau;
}