#include <bits/stdc++.h>
#define fu(i,a,b) for(ll i = a; i <= b; i++)
#define fd(i,a,b) for(ll i = a; i >= b; i--)
#define se second
#define fi first
#define all(x) x.begin(),x.end()
#define NO ""
 
using ull = unsigned long long;
using ll = long long;
using namespace std;
 
typedef pair<ll,ll> ii;
typedef pair<ii,ll> iii;
 
const ll Gmax = 501;
 
ll n,m;
ll f[Gmax][Gmax];
 
int main() {
    freopen("rec.inp","r",stdin);
    freopen("rec.out","w",stdout);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >> n >> m;
 
    fu(i,1,n) {
        fu(j,1,m) {
            if (i == j) f[i][j] = 0;
            else {
                f[i][j] = 1e9;
                fu(k,1,i) f[i][j] = min(f[i][j],f[k][j] + 1 + f[i-k][j]);
 
                fu(k,1,j) f[i][j] = min(f[i][j],f[i][k] + 1 + f[i][j-k]);
            }
        }
    }
    cout << f[n][m];
}