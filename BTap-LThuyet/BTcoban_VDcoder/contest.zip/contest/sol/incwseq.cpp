#include <bits/stdc++.h>

#define task "incwseq"
#define all(v) (v).begin(), (v).end()
#define rep(i, l, r) for (int i = (l); i <= (r); ++i)
#define Rep(i, r, l) for (int i = (r); i >= (l); --i)
#define DB(X) { cerr << #X << " = " << (X) << '\n'; }
#define DB1(A, _) { cerr << #A << "[" << _ << "] = " << (A[_]) << '\n'; }
#define DB2(A, _, __) { cerr << #A << "[" << _ << "][" << __ << "] = " << (A[_][__]) << '\n'; }
#define DB3(A, _, __, ___) { cerr << #A << "[" << _ << "][" << __ << "][" << ___ << "] = " << (A[_][__][___]) << '\n'; }
#define PR(A, l, r) { cerr << '\n'; rep(_, l, r) DB1(A, _); cerr << '\n';}
#define SZ(x) ((int)(x).size())
#define pb push_back
#define eb emplace_back
#define pf push_front
#define F first
#define S second
#define by(x) [](const auto& a, const auto& b) { return a.x < b.x; } // sort(arr, arr + N, by(a));
#define next ___next
#define prev ___prev
#define y1 ___y1
#define left ___left
#define right ___right
#define y0 ___y0
#define div ___div
#define j0 ___j0
#define jn ___jn

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using namespace std;
typedef pair<ll, int> ii;
typedef pair<ii, int> iii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<ll> vl;
const int N = 1e5 + 2;
int n, a[N], w[N], tr[N];
vii bit;
void upd(int p, ll v, int i)
{
    for (; p < N; p += p & -p) if (bit[p].F < v) bit[p] = {v, i};
}
ii query(int p)
{
    ii res = {0, 0};
    for (; p; p -= p & -p) if (res.F < bit[p].F) res = bit[p];
    return res;
}
int main()
{
    freopen(task".inp", "r", stdin);
    freopen(task".out", "w", stdout);
    ios_base::sync_with_stdio(false); cin.tie(nullptr);
    cin >> n;
    rep(i, 1, n) cin >> a[i];
    rep(i, 1, n) cin >> w[i];
    bit.assign(N, {0, 0});
    int u = 0;
    ll ans = 0;
    rep(i, 1, n)
    {
        ii mx = query(a[i] - 1);
        tr[i] = mx.S;
        ll dp = mx.F + w[i];
        if (ans < dp) ans = dp, u = i;
        upd(a[i], dp, i);
    }
    vi res;
    while (u)
    {
        res.eb(u);
        u = tr[u];
    }
    cout << SZ(res) << '\n';
    Rep(i, SZ(res) - 1, 0) cout << res[i] << ' ';
    return 0;
}
