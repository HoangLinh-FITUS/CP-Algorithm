#include <bits/stdc++.h>
#define maxn 100005

using namespace std;
typedef long long lint;

int n, a[maxn], b[maxn];
lint f[maxn], bit[maxn], id[maxn];
int prv[maxn],x[maxn],m;

lint get(int u,int &cs) {
    lint kq=bit[u]; cs=id[u];
    while (u) {
        if (bit[u]>kq) {
            kq=bit[u];
            cs=id[u];
        }
        //kq=max(kq,bit[u]);
        u&=(u-1);
    }
    return kq;
}

void update(int u,lint val,int cs) {
    while (u<=100000) {
        if (bit[u]<val) {
            bit[u]=val;
            id[u]=cs;
        }
        //bit[u]=max(bit[u],val);
        u+=u & (-u);
    }
}


int main() {
    freopen("incwseq.inp","r",stdin);
    freopen("incwseq.out","w",stdout);
    scanf("%d",&n);
    for(int i=1;i<=n;i++) scanf("%d",&a[i]);
    for(int i=1;i<=n;i++) scanf("%d",&b[i]);
    int j;
    for(int i=1;i<=n;i++) {
        f[i]=get(a[i]-1,j)+b[i];
        prv[i]=j;
        update(a[i],f[i],i);
    }
    int u=1;
    for(int i=1;i<=n;i++) if (f[i]>f[u]) u=i;
    cerr << f[u];
    m=0;
    while (u>0) {
        x[++m]=u;
        u=prv[u];
    }
    printf("%d\n",m);
    for(int i=m;i>=1;--i) printf("%d ",x[i]);
    //printf("%I64d",ds);
}
